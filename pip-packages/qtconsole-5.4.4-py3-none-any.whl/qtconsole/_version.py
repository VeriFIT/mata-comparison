version_info = (5, 4, 4)
__version__ = '.'.join(map(str, version_info))
