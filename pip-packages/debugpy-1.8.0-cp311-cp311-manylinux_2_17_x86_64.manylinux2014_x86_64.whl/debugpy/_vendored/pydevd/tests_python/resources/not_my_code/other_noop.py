def call_noop():
    return None
